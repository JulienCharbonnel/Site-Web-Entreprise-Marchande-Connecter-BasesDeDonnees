<?php
  include ("config.php");

  if(empty($_SESSION['login'])){
	  header("Location: connexion.php");
  }

  try // On tente de se connecter a la base de données
    {
        $db = new PDO('mysql:host='.$db_hostname.';dbname='.$dtBase.';charset=utf8', $db_login, $db_password, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]); // On crée une instance de PDO
    }
    catch (Exception $e)
    {
        die('Erreur : ' . $e->getMessage()); // On affiche un message d'erreur si la connexion échoue
    }
  
    $id = $_GET['id']; // On récupère l'id du produit
    $id = filter_var($id, FILTER_SANITIZE_NUMBER_INT); // On filtre l'id pour éviter les injections SQL

    $query = "SELECT id FROM vente WHERE id = :id"; // On prépare la requête pour récupérer l'id du produit
    $recupId = $db->prepare($query); // On prépare la requête
    $recupId->execute(['id' => $id]); // On execute la requête
    $recupLID = $recupId->fetch(); // On récupère le résultat sous forme de tableau

    $query = "SELECT * FROM vente where id=$id"; // On récupère toutes les données de la table vente
    $produits = $db->prepare($query); // On prépare la requête
    $produits->execute(); // On execute la requête
  
    $products = $produits->fetchAll(PDO::FETCH_OBJ); // On recupere le résultat sous forme d'objet

    $query = "SELECT * FROM ExtractionFromTypeItem where typeItem=$id"; // On récupère toutes les données de la table produits
    $materiaux = $db->prepare($query); // On prépare la requête
    $materiaux->execute(); // On execute la requête

    $minerais = $materiaux->fetchAll(PDO::FETCH_OBJ); // On recupere le résultat sous forme d'objet

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ReCircle</title>
  <link rel="stylesheet" href="css/achat.css">
  <link rel="stylesheet" href="css/footer.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
  <link rel="stylesheet" href="css/home.css">
</head>

<!-- header  -->
 <nav>
  <a href="home.php" style="text-decoration: none"><h1 class="link">Recircle</h1></a>
  <div class="onglets">
    <a href="home.php" style="text-decoration: none"><p class="link">Accueil</p></a>
    <a href="achat.php" style="text-decoration: none"><p class="link">Boutique</p></a>
    <a href="vente.php" style="text-decoration: none"><p class="link">Vendre</p></a>
    <a href="contact.php" style="text-decoration: none"><p class="link">Contactez-nous</p></a>
    <a href="panier.php" style="text-decoration: none"><p class="link"><i class="fas fa-shopping-cart"></i></p></a>
    <div class="login">
      <a href="connexion.php"><img src="image/login.png"></a>
    </div>
  </div>
  </nav>

    <?php
	foreach ($products as $product) {
        	echo '<div class="item">'; // On ouvre un div pour chaque produit
        	echo '<img src="image/' .$product->img. '">'; // On affiche l'image du produit
        	echo '<p>' . $product->description . '</p>'; // On affiche la description du produit
        	echo '<h6>'. number_format($product->prix, 2, ',', ' ') . '€ ' . $product-> business . '</h6>'; // On affiche le prix du produit
        	echo '<a href="produitVenteAction.php?id=' . $product->id . '"><button>Vendre</button></a>'; // On affiche un bouton pour vendre le produit
		echo '</div>';
	}
			
	foreach ($minerais as $minerais) {
		echo '<div class="item">'; // On ouvre un div pour chaque produiti
		echo '<p>' . $minerais->nom . '  ' . $minerais->quantity . 'mg' . '</p>'; // On affiche les matériaux et leur quantité
		echo '</div>';
	}
    ?>
    


<?php
  include("footer.php"); // On inclut le footer
?>

	</body>
</html>
