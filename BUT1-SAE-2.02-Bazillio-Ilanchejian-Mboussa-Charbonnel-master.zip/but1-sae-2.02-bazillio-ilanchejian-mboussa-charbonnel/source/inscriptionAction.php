<?php
    require("config.php"); // Pour evitter d'avoir les mdp et le login de visible ici
    if (isset($_POST['email']) and isset($_POST['username']) and isset($_POST['password']))
    {
        $prenom = $_POST['prenom'];
        $email = $_POST["email"];
        $utilisateur = $_POST["username"];
        $mdp = $_POST["password"];

        $prenom = filter_var($prenom, FILTER_SANITIZE_STRING);
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        $utilisateur = filter_var($utilisateur, FILTER_SANITIZE_STRING);
        $mdp = filter_var($mdp, FILTER_SANITIZE_STRING);

        $hash = password_hash($mdp, PASSWORD_DEFAULT);
   
        //On se connecte à la BD
        $conn = mysqli_connect($db_hostname,$db_login,$db_password,$dtBase);

        if (!$conn) die ("probleme de connexion");

        $doublonEmail = mysqli_query($conn ,"SELECT email FROM CustomerProtectedData WHERE email='".trim($email)."'");
        $doublonLogin = mysqli_query($conn ,"SELECT 'login' FROM CustomerProtectedData WHERE 'login'='".trim($utilisateur)."'");
 
        if($row = mysqli_fetch_assoc($doublonEmail)) {  //si au moins une ligne est retournée par le résultat
            echo ("Cette email existe déjà dans la base de données"); 
        }elseif($row1 = mysqli_fetch_assoc($doublonLogin)){
            echo ("Ce login existe déjà dans la base de données"); 
	}else{
	    include_once("config.php"); // Pour evitter d'avoir les mdp et le login de visible ici

  	    try // On tente de se connecter a la base de données
	    {
		    $db = new PDO('mysql:host='.$db_hostname.';dbname='.$dtBase.';charset=utf8', $db_login, $db_password, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]); // On se connecte a la base de données
	    }
	    catch (Exception $e)
	    {
		    die('Erreur : ' . $e->getMessage()); // Si il y a une erreur, on affiche l'erreur
	    }

	    $query = "SELECT * FROM Mendeleiev"; // On récupère toutes les données des matériaux
            $materiaux = $db->prepare($query); // On prépare la requête
    	    $materiaux->execute(); // On execute la requête

    	    $minerais = $materiaux->fetchAll(PDO::FETCH_OBJ); // On recupere le résultat sous forme d'objet

	    $stmt = mysqli_query($conn ,"INSERT INTO CustomerProtectedData VALUES (null, \"$utilisateur\", \"$prenom\", \"$email\", \"$hash\", 0);");
	    foreach($minerais as $minerais) {
		    $data = mysqli_query($conn, "INSERT INTO CustomerExtraction VALUES (\"$utilisateur\", \"$minerais->Z\", \"$minerais->name\", 0);");
	    }
	    header("Location: connexion.php");
        }        
    }
?>   
