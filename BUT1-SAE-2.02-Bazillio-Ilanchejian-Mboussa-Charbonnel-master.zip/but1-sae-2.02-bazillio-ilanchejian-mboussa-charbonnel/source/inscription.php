<html>
    <head>
       <meta charset="utf-8">
        <!-- importer le fichier de style -->
        <link rel="stylesheet" href="css/styleConnexion.css" media="screen" type="text/css" />
        <link rel="stylesheet" href="css/home.css"/>
        <link rel="stylesheet" href="css/footer.css" media="screen" type="text/css" />
        
    </head>
    <body>

    <!-- header  -->
  <nav>
  <a href="home.php" style="text-decoration: none"><h1 class="link">ReCircle</h1></a>
    <div class="onglets">
    <a href="home.php" style="text-decoration: none"><p class="link">Acceuil</p></a>
      <a href="achat.php" style="text-decoration: none"><p class="link">Boutiques</p></a>
      <a href="vente.php" style="text-decoration: none"><p class="link">Vendre</p></a>
      <a href="contact.php" style="text-decoration: none"><p class="link">Contactez-nous</p></a>
 
      <div class="login">
      <a href="connexion.php"><img src="image/login.png" ></a>
</div>
    </div>
  </nav>
  <!-- Fin header -->
    
    <div id="titre">
    </div>
        <div id="container">
           
            <!-- zone de formulaire-->
        <form action="inscriptionAction.php" method="POST">
            <h1>Inscription</h1>
            <label><b>Entrez votre prénom</b></label>
            <input type="text" placeholder="Entrer un prénom" name="prenom" required><br><br>
            <label><b>Entrez votre adresse email</b></label>
            <input type="text" placeholder="Entrer une adresse email valide" name="email" required><br><br> 
            <label><b>Entrez un nom d'utilisateur</b></label>
            <input type="text" placeholder="Entrer un nom d'utilisateur" name="username" required><br><br>
            <label><b>Entrez un mot de passe</b></label>
            <input type="password" placeholder="Entrer un mot de passe" name="password" required><br><br>
            <label><b>Entrez a nouveau votre mot de passe</b></label>
            <input type="password" placeholder="Entrer a nouveau votre mot de passe" name="password" required><br><br>
            <input type="submit" id='submit' value='Enregistrez-vous'>
            <p> Vous possedez déja un compte ici ? <a href="connexion.php">Connectez-vous</a></p>
       </form>
    </div>

    <?php
        include("footer.php"); // On inclut le footer
    ?>

    </body>

</html>
