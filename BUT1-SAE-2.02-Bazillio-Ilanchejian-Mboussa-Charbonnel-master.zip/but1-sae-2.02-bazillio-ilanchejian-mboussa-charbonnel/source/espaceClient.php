<?php
  include_once("config.php"); // Pour evitter d'avoir les mdp et le login de visible ici

  if(!isset($_SESSION['email'])){ // Si l'utilisateur n'est pas connecté
    header("Location: connexion.php"); // On le redirige vers la page de connexion
  }

  try // On tente de se connecter a la base de données
  {
    $db = new PDO('mysql:host='.$db_hostname.';dbname='.$dtBase.';charset=utf8', $db_login, $db_password, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]); // On se connecte a la base de données
  }
  catch (Exception $e)
  {
    die('Erreur : ' . $e->getMessage()); // Si il y a une erreur, on affiche l'erreur
  }

  $id = $_GET['id']; // On récupère l'id du produit
  $id = filter_var($id, FILTER_SANITIZE_NUMBER_INT); // On filtre l'id pour éviter les injections SQL

  $query = "SELECT id FROM vente WHERE id = :id"; // On prépare la requête pour récupérer l'id du produit
  $recupId = $db->prepare($query); // On prépare la requête
  $recupId->execute(['id' => $id]); // On execute la requête
  $recupLID = $recupId->fetch(); // On récupère le résultat sous forme de tableau

  $nom = $_SESSION['login']; // On récupère le nom du client
  
  $query = "SELECT Cagnotte FROM CustomerProtectedData where login='$nom'"; // On récupère la cagnotte
  $argent = $db->prepare($query); // On prépare la requête
  $argent->execute(); // On execute la requête

  $cagnotte = $argent->fetchAll(PDO::FETCH_OBJ);

  $query = "SELECT * FROM CustomerExtraction where login='$nom'"; // On récupère toutes les données de la table produits
    $materiaux = $db->prepare($query); // On prépare la requête
    $materiaux->execute(); // On execute la requête

    $minerais = $materiaux->fetchAll(PDO::FETCH_OBJ); // On recupere le résultat sous forme d'objet


?>

<!DOCTYPE html>
<html lang="en">
  <head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Espace membre</title>
		<link rel="stylesheet" href="css/home.css">
		<link rel="stylesheet" href="css/footer.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
	</head>

    <body>

	<nav>
	<a href="home.php" style="text-decoration: none"><h1 class="link">Recircle</h1></a>
	<div class="onglets">
		<a href="home.php" style="text-decoration: none"><p class="link">Accueil</p></a>
		<a href="achat.php" style="text-decoration: none"><p class="link">Boutique</p></a>
		<a href="vente.php" style="text-decoration: none"><p class="link">Vendre</p></a>
		<a href="contact.php" style="text-decoration: none"><p class="link">Contactez-nous</p></a>
		<a href="panier.php" style="text-decoration: none"><p class="link"><i class="fas fa-shopping-cart"></i></p></a>
		<div class="login">
			<a href="connexion.php"><img src="image/login.png"></a>
		</div>
	</div>
	</nav>


	<?php
  		echo "Bonjour : ".$_SESSION["prenom"]; // On affiche le nom du client
  		echo '<div class="item">'; // On ouvre un div pour chaque produit
		foreach ($cagnotte as $cagnotte) {
			echo '<div class="item">'; // On ouvre un div pour chaque produit
			echo "Votre cagnotte est de : " . number_format($cagnotte->Cagnotte, 2, ',', ' ') . '€'; // On affiche la cagnotte
			echo '</div>'; // On ferme le div
		}
		foreach ($minerais as $minerais) {
			echo '<div class="item">'; // On ouvre un div pour chaque produiti
                	echo '<p>' . $minerais->nom . '  ' . $minerais->quantity . 'mg' . '</p>'; // On affiche les matériaux et leur quantité
			echo '</div>';
		}
	?>
    <p>Bienvenue dans votre espace client, on espère que vous allez bien ! <?php ?> <br/></p>
    <h2> Vos différents achats dernierement </h2>

    <?php

      // On récupère les données de l'utilisateur
      $sqlQuery = 'SELECT * FROM CustomerProtectedData WHERE login = :id'; // On prépare la requête
      $userquery = $db->prepare($sqlQuery); // On la prépare
      $userquery->execute(array(
        'id' => $_SESSION['login'], // On injecte les valeurs
      )); // On execute la requête
            

?>

    <a href="deconnexion.php">Déconnexion</a> 

    <?php
      include("footer.php"); // On inclut le footer
    ?>
    
  </body>
</html>
