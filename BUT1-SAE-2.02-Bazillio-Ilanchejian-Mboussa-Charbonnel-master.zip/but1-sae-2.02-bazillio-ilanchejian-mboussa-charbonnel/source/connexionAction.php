<?php

include_once("config.php"); // Pour evitter d'avoir les mdp et le login de visible ici

if (isset($_POST['email']) && isset($_POST['password'])){ // Si les champs sont remplis

    $email = $_POST['email'];
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);

    try // On tente de se connecter a la base de données
    {
        $db = new PDO('mysql:host='.$db_hostname.';dbname='.$dtBase.';charset=utf8', $db_login, $db_password, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    }
    catch (Exception $e)
    {
        die('Erreur : ' . $e->getMessage());
    }

    $hash = password_hash($_POST['password'], PASSWORD_DEFAULT); // On hash le password

    $sqlQuery = "SELECT * FROM CustomerProtectedData WHERE email = :email"; // On prépare la requête
    $userquery = $db->prepare($sqlQuery); // On la prépare
    $userquery->execute([ // On execute la requête
        'email' => $email, // On injecte les valeurs
    ]);

    $user = $userquery->fetch(); // On récupère les résultats sous forme de tableau


    if ($user){ // Si l'utilisateur existe     
        if(password_verify($_POST['password'], $user['passwd'])){  // Si le mot de passe est correct
            
            header("Location: espaceClient.php?id=' 0'"); // On redirige vers la page d'accueil
            $_SESSION['email'] = $user['email']; // On met les valeurs dans la session
            $_SESSION['prenom'] = $user['prenom']; // On met les valeurs dans la session
            $_SESSION['login'] = $user['login'];           
        }else
            echo "Mauvais email ou mot de passe"; // Sinon on affiche un message d'erreur
    }else
        echo "Mauvais email ou mot de passe"; // Sinon on affiche un message d'erreur           
}
?>


