<?php
include_once("config.php");

if(isset($_SESSION['login'])){
    header("Location: espaceClient.php?id=' 0'?prix=' 0'");
}

?>

<html>
    <head>
       <meta charset="utf-8">
        <!-- importer les fichiers de style -->
        <link rel="stylesheet" href="css/styleConnexion.css" media="screen" type="text/css" />
        <link rel="stylesheet" href="css/footer.css" media="screen" type="text/css" />
        <link rel="stylesheet" href="css/home.css" media="screen" type="text/css" />
    </head>

    <body>
<!-- header  -->
	<nav>
	<a href="home.php" style="text-decoration: none"><h1 class="link">Recircle</h1></a>
	<div class="onglets">
		<a href="home.php" style="text-decoration: none"><p class="link">Accueil</p></a>
		<a href="achat.php" style="text-decoration: none"><p class="link">Boutiques</p></a>
		<a href="vente.php" style="text-decoration: none"><p class="link">Vendre</p></a>
		<a href="contact.php" style="text-decoration: none"><p class="link">Contactez-nous</p></a>

		<div class="login">
			<a href="connexion.php"><img src="image/login.png"></a>
		</div>
	</div>
	</nav>
<!-- Fin header -->


        <div id="container">
            <!-- zone de connexion -->
            <form action="connexionAction.php" method="POST">
                <h1>Connexion</h1>
                
                <label><b>Adresse email</b></label>
                <input type="text" placeholder="Entrer l'adresse email" name="email" required>

                <label><b>Mot de passe</b></label>
                <input type="password" placeholder="Entrer le mot de passe" name="password" required>

                <input type="submit" id='submit' value='CONNEXION' >
                <p> Vous êtes nouveau ici? <a href="inscription.php">S'inscrire</a></p>
            </form>
        </div>

        <?php
            include("footer.php"); // On inclut le footer
        ?>
        
    </body>


</html>
