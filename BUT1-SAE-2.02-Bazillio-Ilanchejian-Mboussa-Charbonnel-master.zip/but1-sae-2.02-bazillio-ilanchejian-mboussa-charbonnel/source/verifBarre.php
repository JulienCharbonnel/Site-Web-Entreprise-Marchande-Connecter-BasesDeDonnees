<?php

include("config.php"); // Pour evitter d'avoir les mdp et le login de visible ici

try // On tente de se connecter à la base de données
{
    $db = new PDO('mysql:host='.$db_hostname.';dbname='.$dtBase.';charset=utf8', $db_login, $db_password, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

}catch(Exception $e)
{    
    die("Une érreur a été trouvé : " . $e->getMessage());
}

if (isset($_GET["s"]) AND $_GET["s"] == "Rechercher"){ // Si on a cliqué sur le bouton "Rechercher"
    
    $terme = $_GET["terme"];
    $terme = filter_var($terme, FILTER_SANITIZE_STRING);

    if (isset($terme)){
        $select_terme = $db->prepare("SELECT nom FROM produits");
        $select_terme->execute(array("%".$terme."%", "%".$terme."%")); //on fait une recherche via la requête preparée dans la BDD
        $nb_result = $select_terme->rowCount();
        if ($nb_result == 0){
            echo "Désolé, aucun résultat n'a été trouvé.";
        }
        else{
            header("Location: recherche.php?terme=".$terme);
            echo $nb_result." résultat(s) trouvé(s) :";
            while ($donnees = $select_terme->fetch()){ //tant qu'il y a des résultats dans la BDD
                echo "<p>".$donnees["titre"]."</p>"; //on affiche le titre
                echo "<p>".$donnees["contenu"]."</p>"; //on affiche le contenu
            }
        }
    }
}


?>