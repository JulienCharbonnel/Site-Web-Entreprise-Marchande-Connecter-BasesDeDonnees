<?php

include("config.php"); // Pour evitter d'avoir les mdp et le login de visible ici

if(isset($_POST['email']) and isset($_POST['message'])){
    $email = $_POST['email']; // On récupère l'email
    $message = $_POST["message"]; // On récupère le message

    // On filtre les envoies des utilisateurs pour éviter les injections SQL
    $email = filter_var($email, FILTER_SANITIZE_EMAIL); // On filtre l'email pour éviter les injections SQL
    $message = filter_var($message, FILTER_SANITIZE_STRING); // On filtre le message pour éviter les injections SQL
    

    try // On tente de se connecter a la base de données
    {
        $db = new PDO('mysql:host='.$db_hostname.';dbname='.$dtBase.';charset=utf8', $db_login, $db_password, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    }
    catch (Exception $e)
    {
        die('Erreur : ' . $e->getMessage()); // Si la connexion échoue, on affiche un message d'erreur
    }

    $sqlquerry = "INSERT INTO contact (email, message) VALUES ('$email', '$message')"; // On prépare la requête
    $recipesStatement = $db->prepare($sqlquerry); // On la prépare
    $recipesStatement->execute([ // On execute la requête
        'user' => $_POST['email'], // On injecte les valeurs
        'message' => $_POST['message'], // On injecte les valeurs
    ]);

    if($recipesStatement->rowCount() > 0) // Si on a une ligne insérée
    {
        echo "Votre message a bien été envoyé, on vous remercie de votre message. On vous recontactera dans les plus bref délais"; // On affiche un message
        echo  '<a href="home.php" style="text-decoration: none"><p class="link">Retournez à l\'acceuil</p></a>'; // On affiche un lien vers la page d'accueil

    }
    else 
    {
        echo "Une erreur est survenue."; // On affiche un message
    }
}
?>