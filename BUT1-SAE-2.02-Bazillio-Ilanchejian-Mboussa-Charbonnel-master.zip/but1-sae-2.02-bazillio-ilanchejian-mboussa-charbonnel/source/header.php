  <!-- header  -->
  <?php
    include_once("config.php");
  ?>
  <nav>
    <a href="home.php" style="text-decoration: none"><h1 class="link">ReCircle</h1></a>
    <div class="onglets">
      <a href="home.php" style="text-decoration: none"><p class="link">Acceuil</p></a>
      <a href="achat.php" style="text-decoration: none"><p class="link">Boutique</p></a>
      <a href="vente.php" style="text-decoration: none"><p class="link">Vendre</p></a>  
      <a href="contact.php" style="text-decoration: none"><p class="link">Contactez-nous</p></a>    
      <form>
	<input type="search" name = "keywords" placeholder="Rechercher">
      </form>
      <a href="panier.php" style="text-decoration: none"><p><i class="fas fa-shopping-cart"></i></p></a>
      <div class="login">
	<a href="connexion.php"><img src="image/login.png" ></a>
      </div>
    </div>
  </nav>
  <!-- Fin header -->
