<?php
    include_once("config.php");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contactez-nous</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/footer.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
		<link rel="stylesheet" href="css/home.css">
</head>

<body class="d-flex flex-column min-vh-100">

	<nav>
	<a href="home.php" style="text-decoration: none"><h1 class="link">Recircle</h1></a>
	<div class="onglets">
		<a href="home.php" style="text-decoration: none"><p class="link">Accueil</p></a>
		<a href="achat.php" style="text-decoration: none"><p class="link">Boutique</p></a>
		<a href="vente.php" style="text-decoration: none"><p class="link">Vendre</p></a>
		<a href="contact.php" style="text-decoration: none"><p class="link">Contactez-nous</p></a>
		<a href="panier.php" style="text-decoration: none"><p class="link"><i class="fas fa-shopping-cart"></i></p></a>
		<div class="login">
			<a href="connexion.php"><img src="image/login.png"></a>
		</div>
	</div>
	</nav>

    <div class="container">
        <h1>Contactez nous</h1>
        <form action="submit_contact.php" method="POST">
            <div class="mb-3">

                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" aria-describedby="email-help">
                <div id="email-help" class="form-text">Il est à but informatif et ne servira en aucun cas à des fins commerciales.</div>
            </div>
            <div class="mb-3">
                <label for="message" class="form-label">Votre message</label>
                <textarea class="form-control" placeholder="Exprimez vous" id="message" name="message"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Envoyer</button>
        </form>
        <br />
    </div>

    <?php include('footer.php'); ?>
</body>
</html>
