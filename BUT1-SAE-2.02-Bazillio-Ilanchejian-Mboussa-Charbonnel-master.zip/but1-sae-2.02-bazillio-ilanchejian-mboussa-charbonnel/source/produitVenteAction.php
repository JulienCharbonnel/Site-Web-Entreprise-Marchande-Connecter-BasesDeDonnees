<?php
  include_once("config.php"); // Pour evitter d'avoir les mdp et le login de visible ici

  try // On tente de se connecter a la base de données
  {
    $db = new PDO('mysql:host='.$db_hostname.';dbname='.$dtBase.';charset=utf8', $db_login, $db_password, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]); // On se connecte a la base de données
  }
  catch (Exception $e)
  {
    die('Erreur : ' . $e->getMessage()); // Si il y a une erreur, on affiche l'erreur
  }

  $id = $_GET['id']; // On récupère l'id du produit
  $id = filter_var($id, FILTER_SANITIZE_NUMBER_INT); // On filtre l'id pour éviter les injections SQL

  $query = "SELECT id FROM vente WHERE id = :id"; // On prépare la requête pour récupérer l'id du produit
  $recupId = $db->prepare($query); // On prépare la requête
  $recupId->execute(['id' => $id]); // On execute la requête
  $recupLID = $recupId->fetch(); // On récupère le résultat sous forme de tableau

  $query = "SELECT * FROM vente where id=$id"; // On récupère toutes les données de la table vente
  $produits = $db->prepare($query); // On prépare la requête
  $produits->execute(); // On execute la requête

  $products = $produits->fetchAll(PDO::FETCH_OBJ); // On recupere le résultat sous forme d'objet

  $nom = $_SESSION['login']; // On récupère le nom du client

  $query = "SELECT Cagnotte FROM CustomerProtectedData where login='$nom'"; // On récupère la cagnotte
  $argent = $db->prepare($query); // On prépare la requête
  $argent->execute(); // On execute la requête

  $cagnotte = $argent->fetchAll(PDO::FETCH_OBJ);

  $query = "SELECT * FROM ExtractionFromTypeItem where typeItem=$id"; // On récupère toutes les données de la table produits
    $materiaux = $db->prepare($query); // On prépare la requête
    $materiaux->execute(); // On execute la requête

    $minerais = $materiaux->fetchAll(PDO::FETCH_OBJ); // On recupere le résultat sous forme d'objet

?>

<?php
        foreach ($products as $products) {
                $prix = $products->prix;
        }
        //On se connecte à la BD
        $conn = mysqli_connect($db_hostname,$db_login,$db_password,$dtBase);
        if (!$conn) die ("probleme de connexion");
	mysqli_query($conn ,"UPDATE CustomerProtectedData SET Cagnotte=Cagnotte+$prix where login='$nom'");
	foreach($minerais as $minerais) {
		mysqli_query($conn, "UPDATE CustomerExtraction SET quantity=quantity+$minerais->quantity where login='$nom' and id=$minerais->element");
	}
	header("Location: espaceClient.php?id=' $id'");
?>
