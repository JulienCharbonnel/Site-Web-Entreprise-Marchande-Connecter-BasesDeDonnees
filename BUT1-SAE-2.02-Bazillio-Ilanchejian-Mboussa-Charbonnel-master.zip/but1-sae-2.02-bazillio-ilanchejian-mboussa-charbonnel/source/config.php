<?php 
    $db_password = '5B35dea2622*';
    $db_login = 'charbonn';
    $db_hostname = 'dwarves.iut-fbleau.fr';
    $dtBase=$db_login;
    session_start();
?>