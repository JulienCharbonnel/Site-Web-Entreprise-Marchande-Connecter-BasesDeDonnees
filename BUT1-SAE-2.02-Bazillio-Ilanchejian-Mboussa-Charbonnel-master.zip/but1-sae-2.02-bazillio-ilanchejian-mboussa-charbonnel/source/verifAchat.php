<?php

include("config.php");



try // On tente de se connecter a la base de données
{
    $db = new PDO('mysql:host='.$db_hostname.';dbname='.$dtBase.';charset=utf8', $db_login, $db_password, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]); // On crée une instance de PDO

}catch (Exception $e){
    die('Erreur : ' . $e->getMessage()); // On affiche un message d'erreur si la connexion échoue
}

if(isset($_GET['envoyer'])){
	foreach($_SESSION['panier'] as $produit){
		$id = $produit->id;
		$name = $produit->name;
		$prix = $produit->price;
		$qty = $produit->qty;

		$commande = $db->prepare("INSERT INTO commande (id_user, id_produit, name, price, qty) VALUES (:id_user, :id_produit, :name, :price, :qty)");
		$commandeExe = $db->prepare($commande);
		$commande->execute(array(
			'id_user' => $_SESSION['login'],
			'id_produit' => $id,
			'name' => $name,
			'price' => $prix,
			'qty' => $qty
		));
	}
	
	echo "votre commande a été prise en compte";
}


?>