<?php
	    
	include ("config.php");

	if(isset($_SESSION['login'])){
	}else {
		header("Location: connexion.php");
	}

	try // On tente de se connecter a la base de données
    {
        $db = new PDO('mysql:host='.$db_hostname.';dbname='.$dtBase.';charset=utf8', $db_login, $db_password, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]); // On crée une instance de PDO
    }
    catch (Exception $e)
    {
        die('Erreur : ' . $e->getMessage()); // On affiche un message d'erreur si la connexion échoue
    }

	/** Ici nous allons gérer la session pour le panier */

	if(!isset($_SESSION)) // Si la session n'est pas démarrée
	{
		session_start(); // On démarre la session
		
	}
	
	if(!isset($_SESSION['panier'])) // Si le panier n'est pas démarré
	{
		$_SESSION['panier'] = array(); // On crée un panier vide
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ReCircle</title>
  <link rel="stylesheet" href="css/achat.css">
  <link rel="stylesheet" href="css/footer.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
  <link rel="stylesheet" href="css/home.css">
 
</head>
<body>
  <!-- header  -->

	<nav>
	<a href="home.php" style="text-decoration: none"><h1 class="link">Recircle</h1></a>
	<div class="onglets">
		<a href="home.php" style="text-decoration: none"><p class="link">Accueil</p></a>
		<a href="achat.php" style="text-decoration: none"><p class="link">Boutique</p></a>
		<a href="vente.php" style="text-decoration: none"><p class="link">Vendre</p></a>
		<a href="contact.php" style="text-decoration: none"><p class="link">Contactez-nous</p></a>
		<a href="panier.php" style="text-decoration: none"><p class="link"><i class="fas fa-shopping-cart"></i></p></a>
		<div class="login">
			<a href="connexion.php"><img src="image/login.png"></a>
		</div>
	</div>
	</nav>

<?php
	if(isset($_GET['id'])){

		$id = $_GET['id']; // On récupère l'id du produit
		$id = filter_var($id, FILTER_SANITIZE_NUMBER_INT); // On filtre l'id pour éviter les injections SQL

		if(in_array($id, $_SESSION['panier'])){
		}

		$query = "SELECT id FROM produits WHERE id = :id"; // On prépare la requête pour récupérer l'id du produit
		$recupId = $db->prepare($query); // On prépare la requête
		$recupId->execute(['id' => $id]); // On execute la requête
		$recupLID = $recupId->fetch(); // On récupère le résultat sous forme de tableau

		if(empty($recupLID)){
			die("Ce produit n'existe pas"); // On affiche un message d'erreur si le produit n'existe pas
		}

		$obj_produit = new stdClass;
		$obj_produit->id = $_GET['id'];
		$obj_produit->name = $_GET['name'];
		$obj_produit->price = $_GET['prix'];
		$obj_produit->qty = 1;

		$_SESSION['panier'][] = $obj_produit;
		$panier = $_SESSION['panier'];
		$nb_produits = count($panier);


		echo '<table cellpad="8" border="1">';
		echo '<tr><th>Produit</th><th>Prix</th><th>Quantité</th></tr>';
	
		if ($nb_produits > 0){
			foreach ($_SESSION['panier'] as $produit){
				echo '<tr><td>'.$produit->name.'</td><td>'.$produit->price.'</td><td>'.$produit->qty.'</td></tr>';
			}	
		}else echo '<tr><td colspan="3">Votre panier est vide !</td></tr>';
			
		echo '</table>';
	
		echo '<form action="verifAchat.php" method="GET">';
		echo '<input type=submit name="envoyer" value=Acheter>';
		echo '</form>';		

	}

	include("footer.php");
?>

</body>
</html>
