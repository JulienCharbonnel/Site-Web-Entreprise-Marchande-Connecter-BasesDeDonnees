<footer class="footer">
	<div class="container">
	<div class="row">
		<div class="footer-col">
			<h4>Acheter</h4>
			<ul>
				<li><a href="achat.php">Nos produits</a></li>
				<li><a href="achat.php">Nos services</a></li>
				<li><a href="partenaires.php">Nos partenaires</a></li>
			</ul>
		</div>
		<div class="footer-col">
			<h4>Vendre</h4>
			<ul>
				<li><a href="vente.php">Vendez chez nous</a></li>
				<li><a href="connexion.php">Connecter vous</a></li>
				<li><a href="espaceClient.php?id=' 0'">Votre espace client</a></li>
			</ul>
		</div>
		<div class="footer-col">
			<h4>Nos partenaires populaires</h4>
			<ul>
				<li><a href="https://www.dell.com/fr-fr">Dell</a></li>
				<li><a href="https://www.apple.com/fr/">Apple</a></li>
				<li><a href="https://www.samsung.com/fr/">Samsung</a></li>
				<li><a href="https://www.asus.com/fr/">Asus</a></li>
			</ul>
		</div>
		<div class="footer-col">
			<h4>Nous soutenir sur les réseaux</h4>
			<div class="social-links">
				<a href="#"><i class="fab fa-facebook-f"></i></a>
				<a href="#"><i class="fab fa-twitter"></i></a>
				<a href="https://www.instagram.com/recircle_sae/"><i class="fab fa-instagram"></i></a>
				<a href="#"><i class="fab fa-linkedin-in"></i></a>
			</div>
		</div>
	</div>
	</div>
</footer>
