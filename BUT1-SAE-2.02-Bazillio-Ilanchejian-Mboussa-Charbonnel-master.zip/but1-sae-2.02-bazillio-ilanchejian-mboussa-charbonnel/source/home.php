<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ReCircle</title>
  <link rel="stylesheet" href="css/home.css">
  <link rel="stylesheet" href="css/footer.css">
  <link rel="stylesheet" href="css/diapo.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
</head>
<body>

  <!-- header  -->
  <nav>
    <a href="home.php" style="text-decoration: none"><h1 class="link">ReCircle</h1></a>
    <div class="onglets">
    <a href="home.php" style="text-decoration: none"><p class="link">Acceuil</p></a>
    <a href="achat.php" style="text-decoration: none"><p class="link">Boutique</p></a>
    <a href="vente.php" style="text-decoration: none"><p class="link">Vendre</p></a>
    <a href="contact.php" style="text-decoration: none"><p class="link">Contactez-nous</p></a>


      <form>
        <input type="search" name = "keywords" placeholder="Rechercher"> 
      </form>

      <?php
        //include("verifBarre.php"); // on inclut le fichier qui va verifier ce qu'on rentre ddans la barre de recherche
      ?>

      <a href="panier.php" style="text-decoration: none"><p class="link"><i class="fas fa-shopping-cart"></i></p></a> <!-- icone panier -->
      
      <div class="login">
      <a href="connexion.php"><img src="image/login.png" ></a> <!-- On ajoute un lien vers la page de connexion -->
</div>
    </div>
  </nav>
  <!-- Fin header -->
  
  <!-- texrte -->
   <header>
     <h1>La seconde vie n'est pas une option, c'est la solution pour vos composants</h1>
     
   </header>
  <!-- Fin du header -->
  
  <!-- Section principale -->
  <section class="main">
    
    <!-- Toutes les cartes -->
    
    <div class="cards">
      
      <div class="card">
      <a href="achat.php"><img src="image/toshiba.jpg"></a>
        <div class="card-header">
          <h4 class="title">Disque dur</h4>
          <h4 class="price">59,99€</h4>
        </div>

        <div class="card-body">
          <p>Disque dur Toshiba</p>
        </div>
      </div>
      
      <div class="card">
        <img src="image/reffroi.jpg">
        <div class="card-header">
          <h4 class="title">Advance AirStream Pro </h4>
          <h4 class="price">30€</h4>
        </div>
        <div class="card-body">
          <p>Refroidisseur pour ordinateur portable 18" avec 2 ports USB</p>
        </div>
      </div>
      
      <div class="card">
        <img src="image/clavier.jpg">
        <div class="card-header">
          <h4 class="title">Module de mémoire</h4>
          <h4 class="price">225,72€</h4>
        </div>
        <div class="card-body">
          <p>G.Skill Trident Z RGB 32Go</p>
        </div>
      </div>
      
     </div>
    <!-- Fin de toutes les cartes -->

    <!-- gallerie 

    <div class="slidershow middle">
        
        <div class="slides">

            <input type="radio" name="r" id="r1">
            <input type="radio" name="r" id="r2" checked>
            <input type="radio" name="r" id="r3">

       
        <div class="slide s1" >
            <img src="image/clavier.jpg" alt="r1" /> </div>
        

        <div class="slide">
            <img src="image/ram.jpg" alt="r2" /> </div>

        <div class="slide">
            <img src="image/toshiba.jpg" alt="r3" /> </div> 

       
    </div>
    </div>
        
        <div class="navigation">
                
                <label for="r1" class="bar"></label>
                <label for="r2" class="bar"></label>
                <label for="r3" class="bar"></label>
 
        </div>
-->
    <!-- Fin de la gallerie -->
    
  </section>
  <!-- Fin de la section principale -->
  
  <?php
  include("footer.php");
  ?>

</body>
</html>
