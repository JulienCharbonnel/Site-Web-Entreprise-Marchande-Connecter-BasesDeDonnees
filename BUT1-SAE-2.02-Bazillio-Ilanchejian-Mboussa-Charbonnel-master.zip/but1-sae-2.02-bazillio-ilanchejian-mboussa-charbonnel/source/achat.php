<?php
  include ("config.php");

  try // On tente de se connecter a la base de données
    {
        $db = new PDO('mysql:host='.$db_hostname.';dbname='.$dtBase.';charset=utf8', $db_login, $db_password, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]); // On crée une instance de PDO
    }
    catch (Exception $e)
    {
        die('Erreur : ' . $e->getMessage()); // On affiche un message d'erreur si la connexion échoue
    }
  
    $query = 'SELECT * FROM produits'; // On récupère toutes les données de la table produits
    $produits = $db->prepare($query); // On prépare la requête
    $produits->execute(); // On execute la requête
  
    $products = $produits->fetchAll(PDO::FETCH_OBJ); // On recupere le résultat sous forme d'objet
?>

<!DOCTYPE html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ReCircle</title>
  <link rel="stylesheet" href="css/achat.css">
  <link rel="stylesheet" href="css/footer.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
  <link rel="stylesheet" href="css/home.css">
  <?php //include("barreDeRecherche.php");?>
</head>
<body>
  <!-- header  -->
  <?php
  include("header.php"); // On inclut le header
  ?>

  <section class="main">
    
    <?php
      foreach ($products as $product) {
        echo '<div class="item">'; // On ouvre un div pour chaque produit
        echo '<img src="image/' .$product->img. '"> '; // On affiche l'image du produit
        echo '<p>' . $product->nom . '</p>'; // On affiche le nom du produit
        echo '<h6>'. number_format($product->prix, 2, ',', ' ') . '€</h6>'; // On affiche le prix du produit
        echo '<a href="produitAchat.php?id=' . $product->id. '&amp;name='. $product->nom . '&amp;prix=' . $product->prix . '"><button>Visualiser</button></a>'; // On affiche un bouton pour ajouter le produit au panier
        echo '</div>';
      }
    ?>
    
  </section>

<?php
  include("footer.php"); // On inclut le footer
?>

</body>
</html>
