# **Rapport**
Bonjour cher lecteur.

Dans ce rapport nous allons vous expliquer les différents aspects et fonctionnalités de notre site.

## _Introduction_
Pour commencer, nous avons essayé de cocher toutes les cases demandées pour la réalisation de ce site. Nous nous sommes donc séparés les tâches de manière à réaliser un maximum des aspects du site. Nous avons tous, grâce à ce projet, bien mieux réussis à comprendre le php et les différentes améliorations que l'on peut apporter à un simple site codé en Html et Css.

## _Php_
Pour cette partie, nous allons parler principalement de Php. Rediriger le client sur la bonne page, se connecter à la base de données et communiquer avec, sont un ensemble de choses possibles grâce au php, et qui nous ont permis de réaliser un site, où le client peut vivre une vrai expérience qui n'est plus que visuelle.

Nous avons par exemple grâce à ce langage, permis au client de se connecter à son compte, ou de le créer si il n'en possède pas. Il peut aussi choisir un article qu'il souhaite vendre, et si il est connecté, sa cagnotte augmentera et les matériaux qu'il a sauvé aussi, tout en fonction de l'article choisis.

## _Les différentes pages et leurs fonctionnalités_
### **Page d'accueil**
Cette page est la première qui apparaît lorsque le client se connecte sur le site. Ainsi, elle donne un accès direct à la quasi totalité des autres pages. Vous pouvez sur toutes les pages naviguer grâce à la barre du menu, vers cettep page, celle d'achat, celle de vente, celle de contact, le panier mais aussi votre compte en étant connecté. Elle permet aussi de se rendre sur la page d'achat avec la courte liste de trois articles visible. De plus, toutes les pages possède le même footer où l'on peut non seulement naviguer sur certaines pages mais aussi accéder à différents sites.

### **Page d'achat**
Cette page permet au client d'ajouter à son panier des articles. Il peut consulter les différents articles disponibles, où l'on peut voir à la fois la photo, le nom et le prix, ainsi qu'appuyer sur le bouton "Visualiser" pour afficher l'article avec sa description. Le bouton "Ajouter au panier" nous emmène sur le panier, et ajoute l'item à ce dernier. Cependant quelques failles dans le panier sont encore présentes et nous en parlerons plus bas.

### **Page de vente**
Cette page ressemble à la page d'achat, à l'exception que ce ne sont pas les mêmes articles qui sont proposés. Dans le même schéma, nous pouvons accéder à la description de chaque produit en vente, qui est complétée de la liste des matériaux, qui seront récupérés par l'entreprise lors de l'achat de ce produit. Ces données composées du nom et de la quantité de chacun des matériaux, seront avec le prix, envoyés dans la base de données et permettront ainsi au client de consulter dans sa page de contact ce qu'il a permis de sauver.

### **Page de contact**
Cette page est permet au client de nous contacter. Le formulaire fonctionne et l'on peut le remplir, une fois terminé, un lien permet de retourner à l'accueil.

### **Page du panier**
Cette page nous affiche normalement le panier. Cependant le panier qui est accessible par la page d'achat n'est pas le même depuis le barre de menu du haut de page. Ce bouton affiche donc un panier fonctionnel mais vide.

### **Page du client**
Cette page n'est pas accessible si l'utilisateur n'est pas connecté et renverra donc sur la page de connexion. Si il l'est, il verra alors apparaître son nom, sa cagnotte et la liste des matériaux qu'il a sauvé.

## _Détails des réussites et échecs_
### **Réussites**
Pour ajouter plus de réalité à notre entreprise, nous avons aussi pris le temps de réaliser un compte Instagram pour permettre à nos clients de nous suivre et d'être au courant de nos dernières nouveautés.

Nous avons aussi ajouter des liens dans le footer pour mener sur les sites internet de nos partenaires fictifs tels qu'Apple ou Dell.

Nous sommes aussi fier d'avoir particulièrement bien réussi l'aspect essentiel de cette Saé, à savoir le php avec par exemple la page du client ou la connexion.

### **Echecs**
La barre de recherche n'est pas fonctionnelle. Elle apparaît correctement et ne renvoie pas d'erreur mais ne permet pas de faire remonter les produits correspondant à la recherche.

Pour le panier dont nous avons parlé, il existe encore quelques soucis. Recharger la page ré ajoute un produit. On ne peut pas non plus supprimer un article ni acheter. En effef le bouton ne mène à rien et renvoie une erreur.

## _Conclusion individuelle_
### **Titouan**
Ce projet m'a permis de me dépasser. J'ai fais de mon mieux pour atteindre nos objectifs à temps et j'ai beaucoup appris sur ce langage au fur et à mesure du projet. Je suis fier de mon équipe et de notre travail, notamment pour la page de vente dont je suis l'auteur, même si il restera toujours des choses à améliorer. Enfin, c'est lors de situations telle que celle-ci que je me rends compte que cette filière me plaît vraiment et que j'ai hâte d'en apprendre plus.

### **Julien**
Ce projet ma permis de développer de belles compétences en PHP, en programmation orientée objet, et en SQL. Ce qui me servira dans mes projets à venir que ce soit pour l'année prochaine ou encore après. Ce site m’a rappelé l’importance d’une équipe au sein d’un projet, mais également l’impact de l’équipe et l'implication de chacun sur la réalisation du projet. Malgré cela, je suis content du site et des fonctionnalités que dispose ce dernier.

### **Shiva**
Ce projet m'a personnellement énormément apporté et j'ai pris du plaisir car les langages qu'on a du utiliser lors de la réalisation de notre site web, (html, css, php), sont des langages que je maitrisais à l'avance. J'ai été dans un groupe où on a tous contribué de la même manière. Cela nous a permis d'avancer très rapidement. Je pense cependant qu'il reste une partie du front-end à ameliorer sur notre site.

### **Jacques**
Pour ma part, j’ai apprécié travailler en équipe car cela m’a beaucoup apporté. Par exemple, savoir communiquer correctement, avec des méthodes comme des comptes rendus réguliers pour de ne pas être perdu. J’ai aussi eu à m’exercer avec le php et l’HTML plus particulièrement, ce qui m’a donné de nouvelles connaissances que je n’avais pas maitrisées, mais aussi dans ma tâche qui était de faire un wireflow le plus lisible possible. Pour finir, je me suis aussi sentis de plus en plus à l’aise au fur et à mesure du projet.

## _Conclusion collective_
Nous sommes tous plus ou moins content de ce projet. Il nous a tous servis à mieux comprendre et maitriser le php, ainsi que s'adapter à un groupe plus grand que d'habitude. Certains aspects peuvent bien sûr être améliorés mais nous sommes tous fier des efforts que nous avons fournis.

---
# **Annexe 1**
Nous allons lister ici des cas de tests très précis qui vous permettrons de juger la qualité de notre travail.

## _Test 1_
Pour commencer, vous pouver tester la création de votre compte sur notre site. Si vous cliquez dans l'onglet signalé par une silhouette humaine en haut à droite, vous arriverez sur la page de connexion. Il faudra ensuite suivre le lien vers la page d'inscription en bas du court formulaire, pour accéder à
cette dernière. Suivez les différentes demandes du formulaire pour créer votre compte. Par la suite vous pourrez alors vous connecter à ce dernier en accèdant à la page de connexion comme
vu précédemment.

## _Test 2_
Ici nous vous proposons de naviguer entre les différentes pages de notre site et ainsi vérifier que le site possède bien la structure décrite dans l'Annexe 2 contenant le WireFlow. Vous pouvez naviguer entre la page d'accueil, la page d'achat, la page de vente, la page de contact, votre panier et votre compte si vous êtes connecté.

## _Test 3_
Voici maintenant venu le temps de procéder à un achat. Pour cela, rendez vous sur la page de la boutique. Choississez un article qui vous plaît, ou rechercher en un grâce à la barre de recherche et appuyer sur le bouton en dessous pour l'ajouter au panier. Vous pouvez désormais consulter votre panier où votre article sera visible.

## _Test 4_
Il est aussi possible de vendre un article. Laisser vous tenter par un des produits que vous posséder et que l'une de nos entreprises partenaires rachète cher ! Dans la page de vente, cliquez sur le bouton "vendre" puis consulter votre compte. Votre cagnotte a augmentée et les matériaux que vous avez permis de sauver aussi.

## _Test 5_
N'hésitez pas à suivre le lien en cliquant sur le bouton représentant le logo d'Instagram et de vous abonner à notre compte !

---
# **Annexe 2**
![WireFlow](WireFlow.png "WireFlow")